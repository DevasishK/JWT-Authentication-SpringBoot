package com.example.JWTAuthenticationSpringboot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JwtAuthenticationSpringbootApplicationTests {

	@Test
	void contextLoads() {
	}

}
